import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { TrackService } from './track.service';

@Component({
  selector: 'app-track-order',
  templateUrl: './track-order.component.html',
  styleUrls: ['./track-order.component.css']
})
export class TrackOrderComponent implements OnInit {

  constructor(
    public toastr: ToastrService,
    public Router: Router,
    private route: ActivatedRoute,
    public _service: TrackService
  ) { }

  OrderId: any;
  TopData: any;
  OrderDeattails: any[] = [];
  checkoutItems: any[] = [];
  Preparing: any;
  Packed: any;
  Shipped: any;
  Delivered: any;
  TotalAmount: any;
  userId: any;

  ngOnInit() {
    debugger
    this.userId = window.localStorage.getItem('UserId');
    if (!(+this.userId > 0))
      this.Router.navigate(['/']);

    this.route.queryParams.subscribe(params => {
      this.OrderId = params['orderId'];
    });
    // this.OrderId = window.localStorage.getItem("OrderId");
    if (this.OrderId) {
      this.trackOrder();
    }
    else {
      this.errMsg = "Order not found. . .";
    }
  }
  getproductId(id: number, PvdId: number) {
    console.log(id)
    this.Router.navigate(['/RatingReview'], { queryParams: { Id: id, ProductVdId: PvdId } });
  }


  goToDetail(Id, variantId) {
    if (+Id && +variantId) {
      this.Router.navigate(['/product-details'], { queryParams: { Id: Id, variantId: variantId } });
    }
  }

  errMsg: any;
  trackOrder() {
    if (+this.OrderId) {
      this._service.track(this.OrderId).subscribe((data: any) => {
        debugger
        console.log(data)
        if (data == "404") {
          this.errMsg = "Order not found. . .";
        }
        var model = {
          Name: data.OrderDetail.User.FirstName + " " + data.OrderDetail.User.MiddleName + " " + data.OrderDetail.User.LastName,
          Address: data.DeliveryAddress.Colony + "," + data.DeliveryAddress.Street + "," + data.DeliveryAddress.City + "," +
            data.DeliveryAddress.StateName + " - " + data.DeliveryAddress.Pincode,
          Phone: data.DeliveryAddress.PhoneNo,
          Coins: data.OrderDetail.DiscountForLoyalityPoints,
          TotalAmount: data.OrderDetail.TotalAmount,
          DeliveryDate: data.OrderDetail.DeliveryDate
        };
        this.TopData = model;

        this.OrderDeattails = [];

        if (data.checkoutItems.length > 0) {
          this.checkoutItems = data.checkoutItems;
          this.errMsg = null;
        }

        switch (data.Status) {
          case "Preparing": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-todo";
            this.Shipped = "progtrckr-todo";
            this.Delivered = "progtrckr-todo";
            break;
          }
          case "Packed": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-done";
            this.Shipped = "progtrckr-todo";
            this.Delivered = "progtrckr-todo";
            break;
          }
          case "Shipped": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-done";
            this.Shipped = "progtrckr-done";
            this.Delivered = "progtrckr-todo";
            break;
          }
          case "Delivered": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-done";
            this.Shipped = "progtrckr-done";
            this.Delivered = "progtrckr-done";
            break;
          }
          default: {
            this.Preparing = "progtrckr-todo";
            this.Packed = "progtrckr-todo";
            this.Shipped = "progtrckr-todo";
            this.Delivered = "progtrckr-todo";
            break;
          }
        }
      })
    }
  }
}
