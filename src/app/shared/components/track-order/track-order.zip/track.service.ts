import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonService } from '../../services/common.service';

@Injectable({
    providedIn: 'root'
})
export class TrackService {
    readonly baseuri = new CommonService().baseuri;
    constructor(private http: HttpClient) { }
    track(id) {
        debugger;
        return this.http.get(this.baseuri + 'shippingGateway/TrackOrder?orderId=' + id);
    }

}
