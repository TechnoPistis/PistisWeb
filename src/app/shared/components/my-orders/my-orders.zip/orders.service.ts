import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { CommonService } from "../../../shared/services/common.service";
@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  data = new CommonService();
  private url = this.data.baseuri;
  constructor(private http: HttpClient) { }

  getOrders() {
    let userId = localStorage.getItem('UserId');
    let IpAddress = localStorage.getItem('IpAddress');
    return this.http.get(this.url + 'orders/userOrders?CustomerId=' + userId + '&IpAddress=' + IpAddress)
  }

  getOrdersById(orderId) {
    let userId = localStorage.getItem('UserId');
    let IpAddress = localStorage.getItem('IpAddress');
    return this.http.get(this.url + 'orders/userOrders?CustomerId=' + userId + '&IpAddress=' + IpAddress + '&orderId=' + orderId)
  }
}
