import { Component, OnInit, AfterViewInit, ViewChild } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { MycartService } from "../mycart/mycart.service";
import { ProductService } from "src/app/shared/components/product-details/product.service";
import { TestimonialService } from "../testimonial/testimonial.service";
import { UserLogService } from '../../services/user-log.service';
import { DatePipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { ApplicationStateServiceService } from '../../services/application-state-service.service';
import { HomePageComponent } from './home-page.component';
import { HomePageService } from './home-page.service';
import { Tracklog } from '../../services/Tracklog.service';
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: "app-home-page-mobile",
  templateUrl: "./home-page.component.mobile.html",
  styleUrls: ["./home-page.component.css"]
})
export class HomePageMobileComponent extends HomePageComponent implements OnInit {
  
  constructor(
     datepipe: DatePipe,
     srevice: HomePageService,
     toastr: ToastrService,
     Router: Router,
     http: HttpClient,
     cartservice: MycartService,
     productService: ProductService,
     testimonialService: TestimonialService, 
     userLog: UserLogService,
     sanitizer:DomSanitizer,
     applicationStateService:ApplicationStateServiceService,
     tracklog:Tracklog
  ) {
      super(datepipe,srevice,toastr,Router,http,cartservice,productService,testimonialService,userLog,sanitizer,applicationStateService,tracklog)
  }
  ngOnInit(){
    super.loadView();
    this.homeCategory();
    this.dealslIst();
    this.getIPAddress();
}
bannerOptions: OwlOptions = {
  loop: false,
  margin:10,
  mouseDrag: false,
  touchDrag: true,
  pullDrag: false,
  dots: true,
  navSpeed: 1000,
  navText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
  responsive:{
      0:{
          items:1,
      },
      600:{
          items:1,
      },
      1000:{
          items:1,
         
      }
  },
  nav: true
}
  homeCategory() {
    this.srevice.getMobileLists().subscribe(x => {
      this.myViewModel.HomeCtegoryList = x as []
      this.myViewModel.HomeCtegoryList.forEach(h => {
        h.products.forEach(d => {
          let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
        d.ActiveTo=correcttime;
        });
        
      });
      this.tracklog.handleSuccess(this.description="Get Mobile Lists rendering on homepage",this.Action="Mobile Lists rendering",JSON.stringify(x))
    },
    error => this.tracklog.handleError(error,this.Action="Mobile Lists rendering")
  
    
    )
  }
  dealslIst() {
    this.srevice.getMobileDealLists().subscribe(x => {
      this.myViewModel.DealList = x as []
      this.myViewModel.DealList.forEach(d => {
        let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
        d.ActiveTo=correcttime;
      });
      this.tracklog.handleSuccess(this.description="Deal Mobile Lists rendering on homepage",this.Action="Deal Lists rendering",JSON.stringify(x))

    },
    error => this.tracklog.handleError(error,this.Action="Deal Mobile  list rendering")
    
    )
  }
   getDealId(dealId: number) {
    this.Router.navigate(["/dealscatalogue"], { queryParams: { Id: dealId } });
  }
  getListId(listId: number) {
    this.tracklog.handleSuccess(this.description="View on get home list button",this.Action="View all homelist button clicked",JSON.stringify("homelistscatalogue?Id="+ listId ))

    this.Router.navigate(["/homelistscatalogue"], { queryParams: { Id: listId } });
  }
  getIPAddress(){
    this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
      
      localStorage.setItem("IpAddress", data["ip"]);
      this.myViewModel.ipAddress = data["ip"];
      this.recentlyViewed();
    });
  }
  recentlyViewed(){
    let UserId=+localStorage.getItem('UserId')
    this.srevice.getRecentlyViewedMobile(UserId,this.myViewModel.ipAddress).subscribe(recent=>{
      this.myViewModel.recent=recent
      this.tracklog.handleSuccess(this.description="Recently list rendering on homepage",this.Action="Recently list rendering",JSON.stringify(recent))
    }
    ,
    error => this.tracklog.handleError(error,this.Action="Recently list rendering")
    )
  }

}