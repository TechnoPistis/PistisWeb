export class Home {
    id:number;
    Name:string;
    ProductCategoryId:number;
    CostPrice:number;
    SellingPrice:number;
    Discount:number;
    PriceAfterdiscount:number;
    Description:string;
}
