import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from './header.component';
import { Router, ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { ApplicationStateServiceService } from '../../services/application-state-service.service';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { MycartService } from '../mycart/mycart.service';
import { CommonHeaderService } from './header.service';
import { TrackService } from '../track-order/track.service';
import { OrdersService } from '../my-orders/orders.service';
import { ToastrService } from 'ngx-toastr';
import { HomePageService } from '../home-page/home-page.service';
import { Menu } from '../front-end/menus/menu';
import { GetCart } from '../mycart/mycartModel';

@Component({
    selector: 'app-header-mobile',
    templateUrl: './header.component.mobile.html',
    styleUrls: ['./header.component.css']
  })
  export class HeaderComponentMobile extends HeaderComponent implements OnInit{
    constructor(
       translate: TranslateService,
       http: HttpClient,
       Router: Router,
       service: MycartService,
       _srevice: HomePageService,
       toastr: ToastrService,
       commonHeaderService: CommonHeaderService,
       route: ActivatedRoute,
       _service: TrackService,
       order_service: OrdersService,
      applicationStateService: ApplicationStateServiceService,
      sanitizer: DomSanitizer,) {
       super(translate, http,Router,service,_srevice,toastr,commonHeaderService,route,_service,order_service,applicationStateService,sanitizer);
     }
     ngOnInit(){
      
      //mobile
      super.loadView();
        this.getMenu().subscribe(res => {
          this.myViewModel.list = res as Menu[]
          this.myViewModel.ProductList = this.myViewModel.list.map(x => x.ProductCategory1 !== null)
          var c = 0;
          var lc = 0;
          
          for (var i of this.myViewModel.list) {
            for (var child of i.ProductCategory1) {
              if (this.slanguage == 'english') {
                if (child.ProductCategory1 != null) {
                  for (var lastchild of child.ProductCategory1) {
                    if (lc == 0) {
                      var index = this.appitems.findIndex(x => x.label == i.Name);
                      if (index > -1) {
                        this.appitems[index].items.push({ label: child.Name, Id: child.Id, items: [{ label: lastchild.Name, Id: lastchild.Id }] })
                      } else {
                        c = 0;
                        this.appitems.push({ label: i.Name, items: [{ label: child.Name, Id: child.Id, items: [{ label: lastchild.Name, Id: lastchild.Id }] }] })
                      }
                    }
                    else {
                      var index = this.appitems.findIndex(x => x.label == i.Name);
    
                      this.appitems[index].items[c].items.push({ label: lastchild.Name, Id: lastchild.Id })
                    }
                    lc++;
                  }
                  this.myViewModel.child = true;
                  c++;
                  lc = 0;
                } else {
                  this.myViewModel.child = false;
                  this.appitems.push({ label: i.Name, Id: i.Id })
                }
              }
    
              else {
    
                if (child.ProductCategory1 != null) {
                  for (var lastchild of child.ProductCategory1) {
                    if (lc == 0) {
                      var index = this.appitems.findIndex(x => x.label == i.SpanishName);
                      if (index > -1) {
                        this.appitems[index].items.push({ label: child.SpanishName, Id: child.Id, items: [{ label: lastchild.SpanishName, Id: lastchild.Id }] })
                      } else {
                        c = 0;
                        this.appitems.push({ label: i.SpanishName, items: [{ label: child.SpanishName, Id: child.Id, items: [{ label: lastchild.SpanishName, Id: lastchild.Id }] }] })
                      }
                    }
                    else {
                      var index = this.appitems.findIndex(x => x.label == i.SpanishName);
    
                      this.appitems[index].items[c].items.push({ label: lastchild.SpanishName, Id: lastchild.Id })
                    }
                    lc++;
                  }
                  this.myViewModel.child = true;
                  c++;
                  lc = 0;
                } else {
                  this.myViewModel.child = false;
                  this.appitems.push({ label: i.SpanishName, Id: i.Id })
                }
    
    
              }
            }
          }
        });
        
     }
  
  }