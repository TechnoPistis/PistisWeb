import { Component, OnInit, HostListener, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { Menu } from '../front-end/menus/menu';
import { HttpClient } from '@angular/common/http';
import { CommonService } from "../../services/common.service";
import { Router, ActivatedRoute } from '@angular/router';
import { GetCart } from '../mycart/mycartModel';
import { Service } from '../../../modules/admin/sub-category/service';
import { MycartService } from '../mycart/mycart.service';
import { ToastrService } from 'ngx-toastr';
import { CommonHeaderService } from './header.service';
import { TrackService } from '../track-order/track.service';
import { OrdersService } from '../my-orders/orders.service';
import { TranslateService } from '@ngx-translate/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { Newsletter } from 'src/app/modules/admin/add-to-newsletter/newsletter';
import { HomePageService } from '../home-page/home-page.service';
import { ApplicationStateServiceService } from '../../services/application-state-service.service';
import { DomSanitizer } from '@angular/platform-browser';
import { HeaderComponentModel } from './header.component.model';
import { HeaderComponentDesktop } from './header.component.desktop';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements AfterViewInit{
 myControl = new FormControl();
 options: string[] = [];
 filteredOptions: Observable<string[]>;
 NewsletterHeading:any="to our newsletter"
 Newsletterdescription:any="Get the latest news, updates and special offers."
 ModalImage = 'assets/img/newsletter-img.jpg';
 ModalImageMobile= 'assets/img/newsletter-img-m.jpg';
 keyword = 'name';
 model: HeaderComponentModel;
 myViewModel: HeaderComponentModel;
 subribe:string="Subscribe  to our newsletter"
 isMobileResolution: boolean=false;
 formData1: Newsletter;
 url = new CommonService().getUri();
 category: any = [];
 cart: any;
 slanguage: any;

//countries:any
  constructor(
    public translate: TranslateService,
    private http: HttpClient,
    private Router: Router,
    public service: MycartService,
    private _srevice: HomePageService,
    private toastr: ToastrService,
    public commonHeaderService: CommonHeaderService,
    private route: ActivatedRoute,
    public _service: TrackService,
    private order_service: OrdersService,
    private applicationStateService: ApplicationStateServiceService,
     private sanitizer: DomSanitizer
  ) {
    this.model = new HeaderComponentModel(sanitizer);
    this.myViewModel = new HeaderComponentModel(sanitizer);
    translate.addLangs(['espanol', 'english']);
    let languageValue = localStorage.getItem("browseLang");
    debugger
    if (languageValue == null) {
      this.translate.setDefaultLang('espanol');
      languageValue = 'espanol';
    }
    else
      this.translate.setDefaultLang(languageValue);
    this.language(languageValue)
    if(languageValue== 'espanol'){
      this.subribe="Suscríbete"
      this.NewsletterHeading="a nuestro boletín de noticias"
      this.Newsletterdescription="Recibe las últimas noticias, actualizaciones y ofertas especiales."
    }else{
      this.subribe="Subscribe"
      this.NewsletterHeading="to our newsletter"
      this.Newsletterdescription="Get the latest news, updates and special offers."
    }
    //this.loadView();
    this.updateView();
    //this.languageChangeOnce(languageValue)
    this.isMobileResolution = applicationStateService.getIsMobileResolution();
  }
  public loadView():void
  {
    this.isMobileResolution = this.applicationStateService.getIsMobileResolution();
    this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
      localStorage.setItem("IpAddress", data["ip"]);
  })
    this.checklanguage()
    if(window.location.href.includes("checkout"))
    {
this.myViewModel.cartCheck=false
    }
    const UserId =+ localStorage.getItem('UserId');
    if (UserId == undefined || UserId == null||UserId==0) {
      this.myViewModel.hidemainDiv = false
    } else {
      this.myViewModel.hidemainDiv = true
    }
    this.myViewModel.loginCheck = false
    this.logincheck()
    this.getCompareProducts().subscribe(res => {

      //alert(JSON.stringify(res))
      this.myViewModel.countCompare = localStorage.getItem("compareCount")
      this.myViewModel.CompareItems = res as []
      console.table(this.myViewModel.CompareItems)
      this.myViewModel.CompareItemLength = this.myViewModel.CompareItems.length

    })
    //menu
    this.getcart();
    this.myViewModel.serachValue = localStorage.getItem("searchData");
    localStorage.setItem("searchData", "")
    this.getcategory().toPromise().then(
      res => {
        
        this.category = res as []
      });
    //Notifications-----get
    this.getNotifications();
    this.commonHeaderService.getSearchTerms().subscribe((x:any)=>{
    //this.countries=JSON.stringify(x)
    this.myViewModel.serachedItems=x as []
    this.myViewModel.serachedItems.forEach((element:any) => {
    this.options.push(element.name)
    });
    })
    //////////
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
    ///////
   }
   private updateView(): void {
     this.myViewModel = this.model.clone();
   }
  handleclick(email:string=''){
    this.myViewModel.display='block'
  }
  AfterViewInit(){}
  getEmail(email: string) {
    let result: boolean;
    let UserId: any;
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    result = re.test(String(email).toLowerCase());
    if (result) {
      UserId = +localStorage.getItem("UserId");
      this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
        this.formData1 = new Newsletter();
        this.ipAddress = data["ip"];
        this.formData1.IpAddress = this.ipAddress;
        this.formData1.Email = email;
        this.formData1.UserId = UserId;
        this.sendata(this.formData1);
        this.myViewModel.searchValue = "";
        this.myViewModel.display = 'none'
      });
    } else {
      var lang = localStorage.getItem("browseLang");
      if (lang == "english") 
        this.toastr.info("Please enter valid Email");
       else 
        this.toastr.info("Por favor introduzca un correo electrónico válido");
    }
  }
  sendata(formData: Newsletter) {
  this.myViewModel.searchValue = "";
    if (formData.UserId == null) {
      formData.UserId = 0;
    }
    var lang = localStorage.getItem("browseLang");
    return this.http
      .post(this.url + "NewsLetter/addNewsLetter", formData)
      .subscribe(res => {
        this.myViewModel.searchValue = "";
        this.myViewModel.display = 'none'
        if(res==0){
          if (lang == "english") {
            this.toastr.info("Already subscribed.");
          } else {
            this.toastr.info("Ya suscrito .");
          }
        }else{
        if (lang == "english") {
          this.toastr.info("Successfully Subscribed.");
        } else {
          this.toastr.info("Suscrito con éxito.");
        }
        }
      });
  }
  onCloseHandled(email:any='') {
    this.myViewModel.searchValue=""
    this.myViewModel.display = 'none';
    ///this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
     // this.ipAddress = data["ip"];
   // })
  //  let UserId = +localStorage.getItem("UserId");
   // this._srevice.checkCancelCounter(UserId, this.ipAddress, 1).subscribe()
  }
  language(val: string) {
    //this.translate.setDefaultLang('espanol');
    localStorage.setItem("browseLang", val)
    this.slanguage = localStorage.getItem("browseLang")
    this.translate.use(this.slanguage);
    this.myViewModel.selectedlang = this.slanguage
  }
  languageChangeOnce(val: string) {
    //this.translate.setDefaultLang('espanol');
    localStorage.setItem("browseLang", val)
    this.slanguage = localStorage.getItem("browseLang")
    this.myViewModel.selectedlang = this.slanguage
    this.translate.use(this.slanguage);
    window.location.reload()
  }
  appitems: any[] = [];
  //////////
  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }
  ////////////
checklanguage(){
  var lang = localStorage.getItem("browseLang");
  if (lang == "english") {
        //this.toastr.info("Kindly,register to try luck in future.");
        this.myViewModel.spanish=false
     } else {
       this.myViewModel.spanish=true
       //   this.toastr.info("Por favor, regístrese para probar suerte en el futuro.");
    }
}
  NotificationLength: any = 0;
  Notifications: any[] = [];
  getNotifications() {
    if (+this.customerId) {
      this.commonHeaderService.Count(this.customerId).subscribe(c=>{
        this.myViewModel.Count=c;
      })
      this.commonHeaderService.getUserNotification(this.customerId, null).subscribe((data: any) => {
        this.NotificationLength = data.length;
        this.Notifications = [];
        this.Notifications = data;
      })
    }
  }
  seeAllNotification() {
    if (+this.customerId) {
      this.Router.navigate(['/AllNotifications']);
    }
  }
  async watchNotification(Id: any) {
    var notification = this.Notifications.filter(b => b.Id == Id)[0];
    if (notification) {
      var typeId = notification.NotificationTypeId;
      if (!typeId)
        return false;
      switch (typeId) {
        case 2:
          await this.readNotification(notification, typeId);
          break;
        case 7:
          await this.readNotification(notification, typeId);
          this.goToDetails(notification);
          break;
        default:
          console.log("No such data exists!");
          break;
      }
    }
  }
  readNotification(notification, typeId) {
    if (notification && notification.Id) {
      this.commonHeaderService.readUserNotification(notification.Id).subscribe((data: any) => {
        if (data) {
          switch (typeId) {
            case 2:
              this.goToOrder(notification);
              break;
            case 7:
              this.goToDetails(notification);
              break;
            default:
              console.log("No such data exists!");
              break;
          }
          console.log('notification seen');
        }
      })
    }
  }
  goToOrder(notification) {
    var url = notification.TargetURL;
    if (url) {
      var orderID = url.split('?')[1].split('=')[1];
      var fullUrl = window.location.href;
      var cUrl = fullUrl.split('/')[1];
      if (+orderID) {
        this.Router.navigate(['/MyOrders'], { queryParams: { orderID: orderID } });
        this.loadView();
      }
    }
  }
  goToDetails(notification) {
    var url = notification.TargetURL;
    if (url) {
      var id = url.split('?')[1].split('=')[1];
      if (+id) {
        this.Router.navigate(['/All-deals'], { queryParams: { Id: id } });
        this.loadView();
      }
    }
  }
  removeNotification(id) {
    if (+id) {
      this.commonHeaderService.removeUserNotification(id).subscribe((data: any) => {
        if (data) {
          console.log('notification removed');
          this.loadView();
        }
      })
    }
  }
  compareProduct() {
    if (this.myViewModel.CompareItemLength >= 2) {
      this.Router.navigate(['/CompareProducts/'])
    }
  }
  ngAfterViewInit() {
    $('[name="admin-style"]').attr('disabled', 'disabled');
    $('[name="front-style"]').removeAttr('disabled');
  }
  productDetail(Id: number, variantId: number) {
    this.Router.navigate(['/product-details'], { queryParams: { Id: Id, variantId: variantId } });
  }
  getMenu() {
    return this.http.get(this.url + 'category/getAllCategory');
  }
  getcategory() {
    return this.http.get(this.url + 'category/getAllCategory');
  }
  getId(id: number) {
    this.Router.navigate(['/productcatalogue/'], { queryParams: { Id: id } });
    event.preventDefault();
  }
  mainSearch(CategoryId: number, searchData: string) {
    if ((searchData == "" || searchData == null || searchData == undefined) && (CategoryId==0 || !CategoryId)) {
      this.Router.navigate(['/'])
     // return false;
    }else if(CategoryId>0 &&(searchData == "" || searchData == null || searchData == undefined)){
    localStorage.setItem("searchData", searchData);
    this.myViewModel.searchData = '';
    this.Router.navigate(['/productcatalogue/'], { queryParams: { Id: CategoryId, searchData: searchData } });
  }
  else{
    localStorage.setItem("searchData", searchData);
    this.myViewModel.searchData = '';
    this.Router.navigate(['/productcatalogue/'], { queryParams: { Id: CategoryId, searchData: searchData } });
  }
}
  //MyCart
  customerId: any;
  ipAddress: string;
  getcart() {
    this.customerId = parseInt(localStorage.getItem("UserId") == null ? "0" : localStorage.getItem("UserId"))
    this.ipAddress = localStorage.getItem("IpAddress");
    this.service.getCart(this.customerId, this.ipAddress).subscribe(data => {
      var allcart = data as GetCart[];
      var i=allcart.findIndex(x=>x.ShipmentVendor==true)
      this.myViewModel.cartItem=[];
      if(window.location.href.indexOf("checkout") > -1)
      {
        if(i>-1)
       this.myViewModel.cartItem.push(allcart[i])
        else
        this.myViewModel.cartItem=allcart
      }
      else
      {
        if(i>-1)
        {
          this.service.removeItem(allcart[i].CartItemId).subscribe(data => {
            allcart.splice(i,1);
            this.myViewModel.cartItem=allcart
          })
        }
        else
        this.myViewModel.cartItem=allcart
      }
      this.myViewModel.cartItem.forEach(e => {
        e.PriceAfterDiscount=+(e.SellingPrice-(e.SellingPrice*e.Discount/100)).toFixed(2)
        e.TotalAmount=+e.TotalAmount.toFixed(2)
      });
      //  console.table(this.cartItem)
      // alert()
     // this.loadView();
    })
  }
  update() {
    // this.getCompareProducts().subscribe(res => {
    //   this.countCompare= localStorage.getItem("compareCount")
    //   this.CompareItems = res as []
    //   this.CompareItemLength = this.CompareItems.length
    // })
  }
  removeItem(CartItemId: number) {
    this.service.removeItem(CartItemId).subscribe(data => {
      let url = this.Router.url;
      var lang = localStorage.getItem("browseLang");
      if (lang == "english") {
        this.toastr.success("Removed item successfully.");
      } else {
        this.toastr.success("Se eliminó el elemento correctamente.");
      }
      if (url == "/mycart") {
        window.location.reload();
        //this.Router.navigate(['/mycart'])
        //this.Router.onSameUrlNavigation='reload'; 
      }
      else {
        this.getcart();
        this.loadView();
      }
    })
  }
  //End MyCart
  getCompareProducts() {
    let UserId: any = +localStorage.getItem("UserId");
    var IpAddress = localStorage.getItem("IpAddress")
    if (UserId == null) {
      UserId = 0
    }
    return this.http.get(this.url + "compare/getCompareProducts?UserId=" + UserId + "&IpAddress=" + IpAddress)
  }
  getProductDetails1(variantId: number) {
    let UserId =+ localStorage.getItem('UserId')
    let IpAddress = localStorage.getItem('IpAddress')
    return this.http.get(this.url + "category/AddWishListProduct?variantId=" + variantId + "&UserId=" + UserId + "&IpAddress=" + IpAddress)
  }
  //   @HostListener('document:mouseout', ['$event'])
  //   mouseout(event: MouseEvent) {
  //     var target = event.target || event.srcElement;
  //     var id = target['id']
  //   if(id=='btnCompare'){
  //     this.getCompareProducts().subscribe( async res => {
  //       this.countCompare= localStorage.getItem("compareCount");
  //       this.CompareItems = res as [];
  //       this.CompareItemLength = await this.CompareItems.length;
  //   //    this.ngOnInit();
  //     })
  //    }
  // //  
  //   }
  logincheck() {
    this.myViewModel.UserName = localStorage.getItem('UserName')
    let userCheck = localStorage.getItem('UserId');
    if (userCheck == null) {
      this.myViewModel.loginCheck = false
    } else {
      if(this.myViewModel.UserName){
      this.myViewModel.loginCheck = true
      }else{
        localStorage.removeItem('UserName')
        localStorage.removeItem('UserId')
        localStorage.removeItem('RoleId')
      }
    }
  }
  deleteCompareproduct(Id: number, index) {
    return this.http.get(this.url + "compare/DeleteCompare?Id=" + Id).subscribe(x => {
      if (x == 1) {
        this.myViewModel.CompareItems.splice(index, 1);
        this.myViewModel.CompareItemLength = this.myViewModel.CompareItems.length
        this.loadView()
        var lang = localStorage.getItem('browseLang')
        if (lang == 'english') {
          this.toastr.success("Product removed.")
        } else {
          this.toastr.success("Producto eliminado.")
        }
      }
    })
  }
  logout() {
    localStorage.removeItem('UserName')
    localStorage.removeItem('UserId')
    localStorage.removeItem('RoleId')
    this.Router.navigate(['/customer/UserLogin'])
  }
  selectedItem(event) {
    var data = event;
    $('#tab_default_1').toggleClass('active');
    this.getId(event.Id);
  }
  ToggleMobileMenu(Id: string) {
    for(let i=1;i<9;i++){
      if("tab_default_"+i==Id)
      {
      $('#' + Id).toggleClass('active');
      } else{
      $('#' + "tab_default_"+i).removeClass('active');
      }
    }
  }
  toggleDropdown(){
    $(".dropdown-content").toggle();
  }
  ///////////santosh sir/////////////////////
  OrderId: any = 143;
  TopData: any;
  OrderDeattails: any[] = [];
  checkoutItems: any[] = [];
  Preparing: any;
  Packed: any;
  Shipped: any;
  Delivered: any;
  TotalAmount: any;
  trackOrder() {
    this.order_service.getOrders().subscribe((response: any[]) => {
      var orders = response;
    });
    if (+this.OrderId) {
      this._service.track(this.OrderId).subscribe((data: any) => {
        var model = {
          Name: data.OrderDetail.User.FirstName + " " + data.OrderDetail.User.LastName,
          Address: data.DeliveryAddress.Address + "," + data.DeliveryAddress.City + "," +
            data.DeliveryAddress.Pincode,
          Phone: data.DeliveryAddress.PhoneNo,
          Coins: data.OrderDetail.DiscountForLoyalityPoints,
          TotalAmount: data.OrderDetail.TotalAmount,
          DeliveryDate: data.OrderDetail.DeliveryDate
        };
        this.TopData = model;
        this.OrderDeattails = [];
        if (data.checkoutItems.length > 0) {
          this.checkoutItems = data.checkoutItems;
        }
        switch (data.Status) {
          case "Preparing": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-todo";
            this.Shipped = "progtrckr-todo";
            this.Delivered = "progtrckr-todo";
            break;
          }
          case "Packed": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-done";
            this.Shipped = "progtrckr-todo";
            this.Delivered = "progtrckr-todo";
            break;
          }
          case "Shipped": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-done";
            this.Shipped = "progtrckr-done";
            this.Delivered = "progtrckr-todo";
            break;
          }
          case "Delivered": {
            this.Preparing = "progtrckr-done";
            this.Packed = "progtrckr-done";
            this.Shipped = "progtrckr-done";
            this.Delivered = "progtrckr-done";
            break;
          }
          default: {
            this.Preparing = "progtrckr-todo";
            this.Packed = "progtrckr-todo";
            this.Shipped = "progtrckr-todo";
            this.Delivered = "progtrckr-todo";
            break;
          }
        }
      })
    }
  }
  keyDownFunction(event, CategoryId: number, searchData: string) {
    if (event.keyCode == 13) {
      this.mainSearch(CategoryId, searchData)
    }
  }
  getDealId(dealId:number){
    if(dealId==0)
    window.location.href="/dealscatalogue?Id=0"
    this.Router.navigate(["/dealscatalogue"], { queryParams: { Id: dealId} });
  }
  goToProfile(){
    localStorage.setItem("reqLink","/MyProfile" )
  }
  goToOrders(){
    localStorage.setItem("reqLink","/MyOrders" )
  }
  goToWishlist(){
    localStorage.setItem("reqLink","/wishlist" )
  }
  //auto complete 
  public countries = [
    {
      id: 1,
      name: 'Albania',
    },
    {
      id: 2,
      name: 'Belgium',
    },
    {
      id: 3,
      name: 'Denmark',
    },
    {
      id: 4,
      name: 'Montenegro',
    },
    {
      id: 5,
      name: 'Turkey',
    },
    {
      id: 6,
      name: 'Ukraine',
    },
    {
      id: 7,
      name: 'Macedonia',
    },
    {
      id: 8,
      name: 'Slovenia',
    },
    {
      id: 9,
      name: 'Georgia',
    },
    {
      id: 10,
      name: 'India',
    },
    {
      id: 11,
      name: 'Russia',
    },
    {
      id: 12,
      name: 'Switzerland',
    }
  ];
    selectEvent(item) {
    // do something with selected item
  }
  onChangeSearch(search: string) {
    // fetch remote data from here
    // And reassign the 'data' which is binded to 'data' property.
  }
  onFocused(e) {
    // do something
  }
}