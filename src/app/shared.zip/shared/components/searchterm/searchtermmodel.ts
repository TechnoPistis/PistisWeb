export class Searchtermmodel {
    Id:number;
    Name:string;
    UserCount:number;
    ProductCount:number;
    IsDisplay:boolean;
    
}
