import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchterm',
  templateUrl: './searchterm.component.html',
  styleUrls: ['./searchterm.component.css']
})
export class SearchtermComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
