import { Component, OnInit, AfterViewInit, ViewChild } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { MycartService } from "../mycart/mycart.service";
import { ProductService } from "src/app/shared/components/product-details/product.service";
import { TestimonialService } from "../testimonial/testimonial.service";
import { UserLogService } from '../../services/user-log.service';
import { DatePipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { ApplicationStateServiceService } from '../../services/application-state-service.service';
import { HomePageComponent } from './home-page.component';
import { HomePageService } from './home-page.service';

@Component({
  selector: "app-home-page-desktop",
  templateUrl: "./home-page.component.desktop.html",
  styleUrls: ["./home-page.component.css"]
})
export class HomePageDesktopComponent extends HomePageComponent implements OnInit {
  
  constructor(
     datepipe: DatePipe,
     srevice: HomePageService,
     toastr: ToastrService,
     Router: Router,
     http: HttpClient,
     cartservice: MycartService,
     productService: ProductService,
     testimonialService: TestimonialService, 
     userLog: UserLogService,
     sanitizer:DomSanitizer,
     applicationStateService:ApplicationStateServiceService
  ) {
      super(datepipe,srevice,toastr,Router,http,cartservice,productService,testimonialService,userLog,sanitizer,applicationStateService)
  }
ngOnInit(){
    this.homeCategory();
    this.dealslIst();
    this.getIPAddress()
}
  homeCategory() {
    this.srevice.getLists().subscribe(x => {
      this.myViewModel.HomeCtegoryList = x as []
      this.myViewModel.HomeCtegoryList.forEach(h => {
        h.products.forEach(d => {
          let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
        d.ActiveTo=correcttime;
        });
        
      });
      console.log(this.myViewModel.HomeCtegoryList)
    })
  }
  dealslIst() {
    this.srevice.getDealLists().subscribe(x => {
      this.myViewModel.DealList = x as []
      this.myViewModel.DealList.forEach(d => {
        let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
        d.ActiveTo=correcttime;
      });
    })
  }
   getDealId(dealId: number) {
    this.Router.navigate(["/dealscatalogue"], { queryParams: { Id: dealId } });
  }
  getIPAddress(){
    this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
      
      localStorage.setItem("IpAddress", data["ip"]);
      this.myViewModel.ipAddress = data["ip"];
      this.recentlyViewed();
    });
  }
  recentlyViewed(){
    let UserId=+localStorage.getItem('UserId')
    this.srevice.getRecentlyViewed(UserId,this.myViewModel.ipAddress).subscribe(recent=>{
      this.myViewModel.recent=recent
    })
  }

}