import { Component, OnInit } from '@angular/core';
import { RegisterService } from "./register.service";
import { ToastrService } from 'ngx-toastr';
import { GlobalErrorHandlerService } from 'src/app/shared/services/global-error-handler-service.service';
import { TranslateService } from '@ngx-translate/core';
import * as $ from "jquery";
import { Router, ActivatedRoute } from '@angular/router';
import { UserLogService } from 'src/app/shared/services/user-log.service';

@Component({
  selector: 'app-customer-register',
  templateUrl: './customer-register.component.html',
  styleUrls: ['./customer-register.component.css']
})
export class CustomerRegisterComponent implements OnInit {
  Url: string;
  productId: any=0;
TermCond:boolean=false
  constructor(private toaster:ToastrService
    , private error: GlobalErrorHandlerService,public translate:TranslateService,
    public service:RegisterService, private route: ActivatedRoute,private router: Router,private userLog:UserLogService) { }

  ngOnInit() {

    this.service.formModel.reset();
    this.Url = this.router.url;
      this.userLog.UserLog(this.productId, 1, this.Url, 1);
  }
  onSubmit(){
    if(this.TermCond=true){
      return false
    }
    this.service.register().subscribe(
      (res:any)=>{
        if(res.ReturnCode==0){
          var lang = localStorage.getItem('browseLang')
          if(lang == 'english'){
            this.toaster.success(res.ReturnMessage,"New UserCreated");
          }else{
            this.toaster.success(res.ReturnMessage,"Nuevo usuario creado");
          }
          
    
          
          this.router.navigate(['/customer/UserLogin'])
          this.service.formModel.reset();
        }
        else{
          var lang = localStorage.getItem('browseLang')
          if(lang == 'english'){
            this.toaster.error(res.ReturnMessage,"Registered User");
          }else{
            this.toaster.error(res.ReturnMessage,"Usuario Registrado");
          }
          
        }
        },
        (error) => {
          
          this.error.handleError(error);
         
            }
    )
  }
  toggleVisibility(e){
    if(e.target.checked){
this.TermCond=false
    }else{
      this.TermCond=true
    }

  }
  ngAfterViewInit() {
    $('[name="front-style"]').attr('disabled', 'disabled');
    $('[name="admin-style"]').removeAttr('disabled');
    }
}
