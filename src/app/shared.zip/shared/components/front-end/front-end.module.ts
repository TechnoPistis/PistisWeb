import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MenusComponent } from "./menus/menus.component";


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    

  ]
})
export class FrontEndModule { }
