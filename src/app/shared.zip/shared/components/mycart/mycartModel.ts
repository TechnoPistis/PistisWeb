import { datepickerAnimation } from 'ngx-bootstrap/datepicker/datepicker-animations';
import { VariantOption } from '../../../modules/admin/products/product.model';

export class MyCart {
    Id:number;
     OrderNumber :string;
    AdditionalCost:number;
        UserId :number;
       IpAddress :string;
        OrderDate :Date;
       TotalAmount :number;
       IsConvertToCheckout :boolean;
       CartItems:CartItem[]=[];
       
}
export class CartItem{
    Id:number;
    CartId :number;
    ProductVariantDetailId:number;
    UnitId :number;
    VendorId:number;
    VendorName:string;
     Quantity :number;
    UnitPrice :number;
     Discount :number;
     Amount :number;
     ShipmentVendor:boolean
     ShipmentCost:number
     ShipmentTime:number
}

export class GetCart{
     Id :number;
     OrderNumber:string;
     VendorId:number;
     UserId:number;
    IpAddress:string;
    OrderDate:Date;
     AdditionalCost:number;
    TotalAmount:number;
    IsConvertToCheckout:boolean;
    //From product
     Image :string;
     Name :string;
     ShipmentVendor:boolean
     ShipmentCost:number
     ShipmentTime:number
    Vendor:string;
    ProductId:any;
    //cartitem
     SellingPrice:number;
    PriceAfterDiscount:any;
    Discount:number;
    DealDiscount:number;
    DealQty:number;
    Quantity:number;
    Amount:number;  
    ProductVariantDetailId:number;
    CartItemId:number;
    VendorName:string;

    VariantOptions:VariantOption[];
    CartItems :CartItem[];
    InStock:number;
}
