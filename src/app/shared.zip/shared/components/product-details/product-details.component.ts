import {
  Component,
  OnInit,
  HostListener,
  Directive,
  EventEmitter,
  Output,
  Input,
  ViewChild,
  AfterViewInit
} from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { Router, ActivatedRoute, Data, NavigationEnd } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { UserLogService } from "src/app/shared/services/user-log.service";
import { ProductService } from "./product.service";
//import { Product } from "./product";
//import { } from "node_modules/ng-drift/lib/ng-drift.js";
import { CartItem, MyCart } from "../mycart/mycartModel";
import { MycartService } from "../mycart/mycart.service";
import { ShippingGatewayService } from "../CommonServices/ShippingGateService";
import { SideCategoryModel } from "../productlist/productlist.model";
import { ProductlistService } from "../productlist/productlist.service";
import { GoogleAnalyticsService } from 'src/app/google-analytics.service';
import { filter, map, mergeMap } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: "app-product-details",
  templateUrl: "./product-details.component.html",
  styleUrls: ["./product-details.component.css"]
})

// @Directive({

//   selector: "[imageZoomm]"
// })
// @Directive({
//   selector: '[stickyThing]'
// })
export class ProductDetailsComponent implements OnInit {
  validUser: any;
  DataCue: any;
  images: any;
  @ViewChild(HeaderComponent,{static:false}) headerData: HeaderComponent;
  varientimages = true;
  data = {
    CustomerId: null,
    ProductId: null,
    IpAddress: null
  };
  product: any;
  Products: any[] = [];
  maincat: SideCategoryModel = new SideCategoryModel();
  dataList: any;
  productId: number;
  LandingVariantId: number;
  ipAddress: any;
  json = "http://ipv4.myexternalip.com/json";
  Url: string;
  date: any;
  myThumbnail: string;
  validCheck = true;
  mouseover: boolean;
  mainImage: boolean = true;
  varientImage: any;
  CustomerTags: any = "";
  getImage: any;
  activeHeart: boolean;
  list: any;
  wishlistLenght: any;
  ComporeProduct: any[] = [];
  enableSticky = true;
  tag123: any = [];
  constructor(
    public datepipe: DatePipe,
    private toastr: ToastrService,
    private Router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private userLog: UserLogService,
    private productService: ProductService,
    public cartservice: MycartService,
    public shipService: ShippingGatewayService,
    public myservice: ProductlistService,
    public googleAnalyticsService:GoogleAnalyticsService,

  ) {
    // this.http.get<{ip:string}>('https://jsonip.com')
    // .subscribe( data => {
    //   console.log('th data', data);
    //   this.ipAddress = data
    // })}
  }
//   ngAfterViewInit(){
//       
//     var scroll = $(window).scrollTop();
// // yada
// $("html").scrollTop(scroll);
//   }





  ngOnInit() {
    this.Router.events.pipe(
      filter((event) => event instanceof NavigationEnd),
      map(() => this.route),
      map((route) => {
        while (route.firstChild) route = route.firstChild;
        return route;
      }),
      filter((route) => route.outlet === 'primary'),
      mergeMap((route) => route.data)
     ).subscribe((event) => {
       this.productService.updateTitle(event['PISTIS']);
       this.productService.updateOgUrl(event['pistis.com.mx']);
       //Updating Description tag dynamically with title
       this.productService.updateDescription(event['Pistis'] + event[''])
     }); 



    this.activeHeart = false;
    this.getImage = localStorage.getItem("ProductImage");
    this.myThumbnail =
      "https://wittlock.github.io/ngx-image-zoom/assets/thumb.jpg";
    this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
      this.route.queryParams.subscribe(params => {
        this.productId = params["Id"];
        if (this.productId != null) {
          this.productService
            .getProducttags(this.productId)
            .subscribe((x: any[]) => {
               
              this.tag123 = x;
              console.log(this.tag123);
            });
        }
        this.LandingVariantId = params["variantId"];
        this.ActiveCheck();
        this.productService
          .getProductDetails(this.productId, this.LandingVariantId)
          .subscribe(res => {
             
            console.log(res)
            this.product = res;
            this.varientImage = this.product.LandingImage450;
            this.myservice
              .getbreadcrumb(this.product.ProductCategoryId)
              .subscribe(all => {
                this.maincat = all;
              });
          });
      });

      this.Url = this.Router.url;
      this.userLog.UserLog(this.productId, 1, this.Url, 1);
      // this.saveBrowseHistory(this.ipAddress ,this.validUser as number,this.productId as number).subscribe()
    });
    //   this.ipAddress=data['ip'])
    // console.log(this.ipAddress);
  }
  passTheSalt() {
  
    //  alert('ghjh')
    this.Router.navigate(["/allreviews"], {
      queryParams: { Id: this.productId, variantId: this.LandingVariantId }
    });
  }
  addCompare() {
    if (this.ComporeProduct.length == 0) {
      this.ComporeProduct.push(this.LandingVariantId);
      this.productService
        .SaveCompareProduct(this.LandingVariantId)
        .subscribe((x: any) => {
          if (x >= 1) {
             
            localStorage.setItem("compareCount", x);
            this.toastr.clear();
            var lang = localStorage.getItem("browseLang");
            if (lang == "english") {
              this.toastr.success("Product added to compare.");
            } else {
              this.toastr.success("Producto agregado para comparar.");
            }
             
             this.headerData.loadView();
          } else {
            this.toastr.clear();
            var lang = localStorage.getItem("browseLang");
            if (lang == "english") {
              this.toastr.info("Product is already add to compare.");
            } else {
              this.toastr.info("El producto ya está agregado para comparar.");
            }
          }
        });
    } else {
      var find = this.ComporeProduct.find(element => {
        return element == this.LandingVariantId;
      });
      if (find == undefined) {
        this.ComporeProduct.push(this.LandingVariantId);
      } else {
        var lang = localStorage.getItem("browseLang");
        if (lang == "english") {
          this.toastr.info("Product is already add to compare.");
        } else {
          this.toastr.info("El producto ya está agregado para comparar.");
        }
      }
    }
  }
  addtags(val: string) {
    this.productService.addtags(this.productId, val).subscribe(x => {
      if (x == 1) {
        var lang = localStorage.getItem("browseLang");
        if (lang == "english") {
          this.toastr.success("Tag added successfully.");
        } else {
          this.toastr.success("Etiqueta agregada con éxito.");
        }

        this.CustomerTags = "";
        this.productService.getProducttags(this.productId).subscribe(x => {
          this.tag123 = x;
        });
      }
    });
  }

  ActiveCheck() {
    this.productService.checkWishlist(this.LandingVariantId).subscribe(x => {
      if (x == 1) {
        this.activeHeart = true;
      } else {
        this.activeHeart = false;
      }
    });
  }

  deleteWishProduct() {
    this.productService.deleteproduct(this.LandingVariantId).subscribe(x => {
      if (x == 1) {
        this.activeHeart = false;
      } else {
        this.activeHeart = true;
      }
    });
  }

  onSend(val: number) {
     
    if (val == 1) {
      this.activeHeart = true;
      var lang = localStorage.getItem("browseLang");
      if (lang == "english") {
        this.toastr.success("Added to wishlist.");
      } else {
        this.toastr.success("Añadido a la lista de deseos.");
      }

      this.productService
        .getProductDetails1(this.LandingVariantId)
        .subscribe(res => {
           
          //this.list = res as []
        });
    } else {
       
      this.activeHeart = false;
      this.deleteWishProduct();
    }
  }
  demoTrigger = document.querySelector(".demo-trigger");
  paneContainer = document.querySelector(".detail");

  // new Drift(demoTrigger, {
  //   paneContainer: paneContainer,
  //   inlinePane: false,
  // });

  // @HostListener('window:unload', [ '$event' ])
  // unloadHandler(event) {
  //
  // // ...
  // localStorage.setItem('LogOutDate', this.date.toDateString() );
  // this.userLog.UserLog(this.productId,1,this.Url,1)
  // }

  @HostListener("window:beforeunload", ["$event"])
  beforeUnloadHander(event) {
    this.date = new Date();
    localStorage.setItem("LogOutDate", this.date);
    // localStorage.setItem('LogInDate', this.date );
    this.DataCue = localStorage.getItem("LogOutDate");
    console.log(this.DataCue);
    this.userLog.UserLog(this.productId, 1, this.Url, 1);
  }

  saveBrowseHistory(IpAddress, customerId: number, productId: number) {
    this.data.CustomerId = customerId;
    this.data.IpAddress = IpAddress;
    this.data.ProductId = productId;
    return this.http.post(
      "http://api.sathfere.com/api/CustomerHistory/saveCustomerHistory",
      this.data
    );
  }

  getFilterData(color, variantId, optionId, event) {
    if (!color) {
      $(event.target.parentElement.previousElementSibling).attr("unchecked");
      return false;
    } else {
      var selectOptions = [];
      var select = $(
        event.target.parentElement.parentElement.parentElement.parentElement
          .parentElement.parentElement.parentElement.parentElement.parentElement
          .previousElementSibling
      ).find("select");
      var size = select.length;
      for (var i = 0; i < size; i++) {
        selectOptions.push(parseInt(select[i].value));
      }
      selectOptions.push(optionId);
      this.productService
        .filterVariantDetails(this.productId, selectOptions.join(","))
        .subscribe((data: any) => {
          if (!data || !data.VariantDetailId) {
            $(event.target.parentElement.previousElementSibling).attr(
              "unchecked"
            );
            this.toastr.clear();
            var lang = localStorage.getItem("browseLang");
            if (lang == "english") {
              this.toastr.error(
                "Sorry this variant is not available currently !"
              );
            } else {
              this.toastr.error(
                "Lo sentimos, esta variante no está disponible actualmente."
              );
            }

            return false;
          } else {
            this.product = data;
            this.product.ActiveTo=this.datepipe.transform(this.product.ActiveTo, 'yyyy-MM-dd');
            this.LandingVariantId = data.VariantDetailId;
            this.varientImage = this.product.LandingImage450;
            console.log(this.product);
          }
        });
    }
  }

  onclick(id: number) {
    this.Router.navigate(["/header"], { queryParams: { Id: id } });
  }

  // @HostListener('mousemove', ['$event'] )
  // zoomIn(event) {
  //
  //   var element = document.getElementById("overlay");
  //   element.style.display = "inline-block";
  //   var img = document.getElementById("imgZoom");
  //   var posX = event.offsetX ? (event.offsetX) : event.pageX - img.offsetLeft;
  //   var posY = event.offsetY ? (event.offsetY) : event.pageY - img.offsetTop;
  //   element.style.backgroundPosition=(-posX*2)+"px "+(-posY*4)+"px";

  // }

  // zoomOut() {
  //
  //   var element = document.getElementById("overlay");
  //   element.style.display = "none";
  // }
  //display image as main image
  getValue(val:any,i:any) {
       
this.varientImage=this.product.Images450[i];
     //this.varientImage=val
    //this.varientImage = this.product.images450x450[i];
    // this.mainImage = false
    // alert(this.varientImage)
    // console.log(this.varientImage)
  }

  getVarientOptionId(event: any, variantId) {
    var id = event.target.value;
    this.productService
      .getVariantDetails(id, this.productId)
      .subscribe((data: any) => {
        if (!data || !data.VariantDetailId) {
          this.toastr.clear();
          var lang = localStorage.getItem("browseLang");
          if (lang == "english") {
            this.toastr.error(
              "Sorry this variant is not available currently !"
            );
          } else {
            this.toastr.error(
              "Lo sentimos, esta variante no está disponible actualmente !"
            );
          }

          return false;
        } else {
          this.product = data;
          this.LandingVariantId = data.VariantDetailId;
          this.varientImage = this.product.LandingImage450;
          console.log(this.product);
        }
      });
  }

  getVarientOptions(event: any, variantId) {
    var selectOptions = [];
    var select = $(event.target.parentElement.parentElement.parentElement).find(
      "select"
    );
    var size = select.length;
    for (var i = 0; i < size; i++) {
      selectOptions.push(parseInt(select[i].value));
    }
    this.productService
      .filterVariantDetails(this.productId, selectOptions.join(","))
      .subscribe((data: any) => {
        if (!data || !data.VariantDetailId) {
          this.toastr.clear();
          var lang = localStorage.getItem("browseLang");
          if (lang == "english") {
            this.toastr.error(
              "Sorry this variant is not available currently !"
            );
          } else {
            this.toastr.error(
              "Lo sentimos, esta variante no está disponible actualmente !"
            );
          }

          return false;
        } else {
          this.product = data;
          this.LandingVariantId = data.VariantDetailId;
          this.varientImage = this.product.LandingImage450;
          console.log(this.product);
        }
      });
  }

  addToCart() {
    this.Products.push(this.product);
    let pro = this.Products;
    let item: CartItem = new CartItem();
    item.ProductVariantDetailId = this.LandingVariantId;
    item.UnitPrice = pro[0].SellingPrice;
    item.Discount = pro[0].Discount;
    item.Amount = pro[0].PriceAfterdiscount;
    item.ShipmentVendor=pro[0].ShipmentVendor
    let cart: MyCart = new MyCart();
    cart.IpAddress = localStorage.getItem("IpAddress");
    cart.UserId = parseInt(
      localStorage.getItem("UserId") == null
        ? "0"
        : localStorage.getItem("UserId")
    );
    cart.TotalAmount = pro[0].PriceAfterdiscount;
    cart.CartItems.push(item);

    this.cartservice.addToCart(cart).subscribe(data => {
        
       this.headerData.loadView();
     
      
if(data)
{
   if(cart.UserId>0) 
this.Router.navigate(["/checkout-process/checkout"]);
else
this.Router.navigate(["/checkout-process/checkout-login"])
}
      
      else
      {
         var lang = localStorage.getItem("browseLang");
      if (lang == "english") {
        this.toastr.success("Product added successfully.");
      } else {
        this.toastr.success("Producto agregado con éxito.");
      }
      this.Router.navigate(["/mycart"]);
      }
      this.googleAnalyticsService.eventEmitter("add_to_cart", "shop", "cart", "click", 10);
    });
  }

  //-----------shipping charges-------------------
  PostalCode: any;
  ShippingCharges: any;
  ShipModel = {
    DeliveryType: "",
    ResponseFrom: "",
    ShipPrice: 0,
    DeliveryDate: ""
  };

  ShippingError: any;
  isShipError: boolean = false;
  errMsg: any;

  checkCharges() {
     
    if (+this.PostalCode) {
      var model = {
        CountryCode: "MX",
        Postalcode: this.PostalCode,
        productId: this.productId,
        variantId: this.LandingVariantId
      };

      this.shipService.CalculateCharges(model).subscribe((data: any) => {
         
        if (data.length > 0) {
          this.ShippingCharges = data;
          this.isShipError = false;
          this.ShippingError = null;
          this.errMsg = "";
        } else {
          if (data.Note === "Failure") {
            this.isShipError = true;
            this.errMsg = "* " + data.Message.split(".")[0];
          }
          //   this.ShippingError = data;
          // this.ShippingError.Message = this.ShippingError.Message.split('.')[0] + ".";
        }
      });
    } else {
      this.isShipError = true;
      var lang = localStorage.getItem("browseLang");
      if (lang == "english") {
        this.errMsg = "* Enter valid postal code";
      } else {
        this.errMsg = "* Ingrese un código postal válido";
      }

      return false;
    }
  }

  goToGetProducts(id) {
    this.Router.navigate(["/productcatalogue/"], { queryParams: { Id: id } });
    event.preventDefault();
  }
}
