export class shippingModel {
    Id:number;
    UserId:number;
    IpAddress:string;
    Address:string;
    Name:string;
    PhoneNo:string;
    Pincode:string;
    City:string;
    StateId:number
    StateName:string
    LandMark:string;
    CountryId:number;
    AddressType:string;
    IsActive:boolean;
    IsDefault:boolean;
    Email:string
}