import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-data',
  templateUrl: './footer-data.component.html',
  styleUrls: ['./footer-data.component.css']
})
export class FooterDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
