import { ProductlistComponent } from './productlist.component';
import { Component, AfterViewInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';
import { CategoryService } from 'src/app/modules/admin/product-category/category.service';
import { ProductlistService } from './productlist.service';
import { MycartService } from '../mycart/mycart.service';
import { ActivatedRoute,Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { SearchTermService } from '../searchterm/search-term.service';
import { UserLogService } from '../../services/user-log.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ApplicationStateServiceService } from '../../services/application-state-service.service';

@Component({
  selector: 'app-productlist-mobile',
  templateUrl: './productlist.component.mobile.html',
  styleUrls: ['./productlist.component.css']
})


export class ProductlistMobileComponent extends ProductlistComponent implements AfterViewInit{
    constructor( 
         datepipe: DatePipe,
         http: HttpClient,
         spinner: NgxSpinnerService,
         service: CategoryService, 
         myservice: ProductlistService,
         cartservice: MycartService, 
         route: ActivatedRoute, 
         Router: Router, 
         toastr: ToastrService, 
         serviceTerm: SearchTermService,
         userLog:UserLogService,
         sanitizer:DomSanitizer,
         applicationStateService:ApplicationStateServiceService) 
        {
          super(datepipe,http,spinner,service,myservice,cartservice,route,Router,toastr,serviceTerm,userLog,sanitizer,applicationStateService)
         }
         ngAfterViewInit() {
          debugger
          this.myservice.appDrawer = this.appDrawer;
        } 
}