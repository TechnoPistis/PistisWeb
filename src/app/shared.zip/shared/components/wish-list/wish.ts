export class Wish {
}
