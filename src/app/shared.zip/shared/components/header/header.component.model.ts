import { DomSanitizer } from '@angular/platform-browser';
import { Menu } from '../front-end/menus/menu';
import { CommonService } from '../../services/common.service';
import { GetCart } from '../mycart/mycartModel';

export class HeaderComponentModel {
  onMain: Boolean;
  menus: Promise<Menu[]>;
  clickedValue: string;
  ProductList: boolean[];
  child: boolean;
  public dataList: any = [];
 
  list: Menu[];
  url = new CommonService().getUri();
  serachValue: string = "";
  CompareItems: [] = []
  CompareItemLength: number
  countCompare: any
  loginCheck: boolean
  hidemainDiv: boolean = false;
  UserName: string
  searchData: string = ''
  mainSelected: any;
  english = 1;
  Spanish = 2;
  slanguage: any;
  CurrentUrl: string = "";
  selectedlang = "espanol"
  UserId =+ localStorage.getItem('UserId');
  Count: any;
  spanish:boolean;
  display = 'none';
cartCheck:boolean=true
searchValue: string="";
serachedItems:[]=[];
cartItem: GetCart[] = [];

  constructor(private sanitizer: DomSanitizer) {
    this.onMain=false;
    //clonedModel.menus=new Promise<Menu[]>;
    this.clickedValue='';
    this.ProductList=[];
    this.child=false;
    this.dataList= [];
    //clonedModel.list=new Menu[];
    this.url = new CommonService().getUri();
    this.serachValue = "";
    this. CompareItems = []
    this.CompareItemLength=0
    this.countCompare=0
    this.loginCheck=false
    this.hidemainDiv = false;
    this.UserName=''
    this.searchData = ''
    this.mainSelected='';
    this.english = 1;
    this.Spanish = 2;
    this.slanguage='';
    this.CurrentUrl= "";
    this.selectedlang = "espanol"
    this.UserId =+localStorage.getItem('UserId');
    this.Count=0;
    this.spanish=false;
    this.cartCheck=true
    this.searchValue="";
    this.serachedItems=[]
    this.cartItem = [];
    //this.imageUrl = this.sanitizer.bypassSecurityTrustResourceUrl('');
  }
  public clone(): HeaderComponentModel {
    let clonedModel: HeaderComponentModel = new HeaderComponentModel(this.sanitizer);
    clonedModel.onMain=false;
    clonedModel.cartItem = [];
    clonedModel.clickedValue='';
    clonedModel.ProductList=[];
    clonedModel.child=false;
     clonedModel.dataList= [];
    //clonedModel.list=new Menu[];
    clonedModel.url = new CommonService().getUri();
    clonedModel.serachValue = "";
    clonedModel. CompareItems = []
    clonedModel.CompareItemLength=0
    clonedModel.countCompare=0
    clonedModel.loginCheck=false
    clonedModel.hidemainDiv = false;
    clonedModel.UserName=''
    clonedModel.searchData = ''
    clonedModel.mainSelected='';
    clonedModel.english = 1;
    clonedModel.Spanish = 2;
    clonedModel.slanguage='';
    clonedModel.CurrentUrl= "";
    clonedModel.selectedlang = "espanol"
    clonedModel.UserId =+ localStorage.getItem('UserId');
    clonedModel.Count=0;
    clonedModel.spanish=false;
    clonedModel.cartCheck=true;
    clonedModel.searchValue=""
    clonedModel.serachedItems=[]
    return clonedModel;
  }
}