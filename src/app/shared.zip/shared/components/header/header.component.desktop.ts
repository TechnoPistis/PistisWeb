import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { HeaderComponent } from './header.component';
import { Router, ActivatedRoute } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import { ApplicationStateServiceService } from '../../services/application-state-service.service';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { MycartService } from '../mycart/mycart.service';
import { CommonHeaderService } from './header.service';
import { TrackService } from '../track-order/track.service';
import { OrdersService } from '../my-orders/orders.service';
import { ToastrService } from 'ngx-toastr';
import { HomePageService } from '../home-page/home-page.service';

@Component({
    selector: 'app-header-desktop',
    templateUrl: './header.component.desktop.html',
    styleUrls: ['./header.component.css']
  })
  export class HeaderComponentDesktop extends HeaderComponent  {
  
    constructor(
       translate: TranslateService,
       http: HttpClient,
       Router: Router,
       service: MycartService,
       _srevice: HomePageService,
       toastr: ToastrService,
       commonHeaderService: CommonHeaderService,
       route: ActivatedRoute,
       _service: TrackService,
       order_service: OrdersService,
      applicationStateService: ApplicationStateServiceService,
      sanitizer: DomSanitizer,) {
       super(translate, http,Router,service,_srevice,toastr,commonHeaderService,route,_service,order_service,applicationStateService,sanitizer);
     }
     
  
  }