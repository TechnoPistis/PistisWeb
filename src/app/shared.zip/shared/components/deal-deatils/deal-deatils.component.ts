import { Component, OnInit, DebugElement, ViewChild, ElementRef } from '@angular/core';
import { HomePageService } from "../home-page/home-page.service";
import { Menu } from "../front-end/menus/menu";

import { ActivatedRoute, Router } from '@angular/router';
import { CategoryService } from 'src/app/modules/admin/product-category/category.service';
import { Filter, SideCategoryModel } from './deal';
import { IfStmt } from '@angular/compiler';
import { Category } from '../../../modules/admin/product-category/category';
import { MycartService } from '../mycart/mycart.service';
import { Product } from 'src/app/modules/admin/products/product.model';
import { MyCart, CartItem } from '../mycart/mycartModel';
import { ToastrService } from 'ngx-toastr';
import { HeaderComponent } from '../header/header.component';
import { VERSION } from '@angular/material';
import { SearchTermService } from '../searchterm/search-term.service';
import { Searchtermmodel } from '../searchterm/searchtermmodel';
import { NgxSpinnerService } from "ngx-spinner";
import { UserLogService } from '../../services/user-log.service';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { DealService } from './deal.service';

@Component({
  selector: 'app-deal-deatils',
  templateUrl: './deal-deatils.component.html',
  styleUrls: ['./deal-deatils.component.css']
})


export class DealDeatilsComponent implements OnInit {

  @ViewChild('appDrawer',{static:false}) appDrawer: ElementRef;
  version = VERSION;

  filter: Filter = new Filter();
  selectedItem: string;
  selectedSize: number;
  selectedReview: number;
  @ViewChild(HeaderComponent,{static:false}) headerData: HeaderComponent;
  selectedCategory: number;
  selectedSizeArray: any[] = [];
  minPriceBox: string;
  maxPriceBox: string;
  list: Menu[];
  menus: Promise<Menu[]>;
  ProductList: boolean[];
  child: boolean;
  count: number = 0; page: number = 1; perPage: number = 10; pagesToShow: number = 10;
  pricelist: any[] = [];
  public Products: any = [];
  subCat: string = "";
  Cat: string;
  CatId: number;
  catvalue: number;
  isChecked: any;
  Variants = [];
  slanguage: any
  Variant = {
    init: function (CategoryId, VariantId, VariantOptionId) {
      this.CategoryId = CategoryId;
      this.VariantId = VariantId;
      this.VariantOptionId = VariantOptionId;
    },
  }
  IsGrid: boolean;
  IsList: Boolean = true;
  selectedVariants = [];
  searchData: string = "";
  SortData: string = "NewArrival";
  maincat: SideCategoryModel = new SideCategoryModel();
  abovecat: SideCategoryModel = new SideCategoryModel();
  model: any;
  Url: string;
  productId: any=0;
  ipAddress: any;

  constructor( 
    public datepipe: DatePipe,
    private http: HttpClient,
    private spinner: NgxSpinnerService,
    public service: CategoryService, public myservice: DealService, public cartservice: MycartService, private route: ActivatedRoute, private Router: Router, private toastr: ToastrService, public serviceTerm: SearchTermService,private userLog:UserLogService) {
  }

  ngOnInit() {
    let userId = +localStorage.getItem('UserId')
    if (userId == null || userId == undefined || userId == 0) {
      this.http.get("https://api.ipify.org/?format=json").subscribe(data => {
        localStorage.setItem("IpAddress", data["ip"]);
      this.ipAddress = data["ip"];
      
      });
    }
    this.Url = this.Router.url;
      this.userLog.UserLog(0, 1, this.Url, 1);
    this.spinner.show();
    this.slanguage = localStorage.getItem('browseLang')
    this.IsGrid = true;
    this.route.queryParams.subscribe(params => {
      this.catvalue = params['Id'];
      this.page = 1
      this.perPage = 15
      this.selectedCategory = this.catvalue;
      this.searchData = params['searchData'];
      if (this.searchData != "") {
        this.filter.SearchData = this.searchData;
        //this.getMainSearchProducts(this.catvalue, this.searchData, this.page, this.perPage);
      }
      this.getMainSearchProducts(this.catvalue, this.searchData, this.page, this.perPage);
      this.getVariants();
    });
      
   
  }
  getVariants() {
    this.myservice.getVariants(this.catvalue).subscribe(data => {
      this.Variants = data as [];
    })
  }

  emptyProductsList: any = false;

  getMainSearchProducts(catvalue: number, searchData: string, page: number, pageSize: number): boolean {
    //this.myservice.getproductsByCategoryData(catvalue, searchData, page, pageSize).subscribe(data => {
    
    this.filter.CategoryId = catvalue;
    this.filter.SearchData = searchData;
    this.spinner.show();
    this.myservice.getFilterProducts(this.filter, page, pageSize).subscribe((data) => {
      this.service.getCategoryHierarchy(this.catvalue).subscribe(category => {
        
        this.Cat = category;
      })
      this.myservice.getproductsAllCat(this.catvalue).subscribe(all => {
        
        this.maincat = all;
      })
      this.myservice.getproductsAboveCat(this.catvalue).subscribe(all => {
       
        this.abovecat = all;
      })
      this.service.getSubCat(this.catvalue).subscribe(subcategory => {
        this.subCat = subcategory
      })
        
      this.Products = data;
      this.Products.forEach(d => {
        let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
        d.ActiveTo=correcttime;
      });
      this.model = new Searchtermmodel();
      this.model.Name = this.searchData;
      this.model.UserCount = 1;
      if (this.Products.length > 1){
        this.model.ProductCount = this.Products[0].Count
        this.emptyProductsList=false;
        this.spinner.hide();
      }
      else{
        this.emptyProductsList=true;
        this.model.ProductCount = 0;
        this.spinner.hide();
      }
      this.serviceTerm.addSearchTerm(this.model).subscribe(term => {

      })
      if (this.Products.length > 1) {
        this.count = this.Products[0].Count;
        this.pricelist = this.Products[0].PriceList;
      }
      else {
        this.count = 0;
        this.pricelist = [];
      }
    })
    
    return false;
  }
  
  getProducts(catvalue: number, page: number, pageSize: number): boolean {
      
    this.selectedCategory = catvalue;
    this.filter.CategoryId = catvalue
    this.catvalue = catvalue;
    //this.myservice.getproductsByCategoryData(catvalue,this.searchData, page, pageSize).subscribe(data => {
    this.myservice.getFilterProducts(this.filter, page, pageSize).subscribe((data) => {
      this.service.getCategoryHierarchy(this.catvalue).subscribe(category => {
        this.Cat = category;
      })
      this.myservice.getproductsAllCat(this.catvalue).subscribe(all => {
        this.maincat = all;
      })
      this.myservice.getproductsAboveCat(this.catvalue).subscribe(all => {
          
        this.abovecat = all;
      })
      this.service.getSubCat(this.catvalue).subscribe(subcategory => {
        this.subCat = subcategory
      })
        
      this.Products = data;
      this.Products.forEach(d => {
        let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
        d.ActiveTo=correcttime;
      });
      if (this.Products.length > 0) {
        this.count = this.Products[0].Count;
        if(this.count==0)
        this.emptyProductsList=true;
        this.pricelist = this.Products[0].PriceList;
      }
      else {
        this.count = 0;
        this.emptyProductsList=true;
        this.pricelist = [];
      }
    })
    
    return false;
    
  }


  getFilterData(e: any, VariantId: number, VariantOptionId: number) {
    if (e == true || e == false) {
      this.isChecked = e;
    }
    else {
      var index = this.selectedSizeArray.findIndex((x) => x == e)
      if (index > -1) {
        this.selectedSizeArray.splice(index, 1);
        this.isChecked = false;
      }
      else {
        this.selectedSizeArray.push(e);
        this.isChecked = true;
      }
    }
    let variant1 = Object.create(this.Variant);
    let VariantOptionIdArray = [];
    VariantOptionIdArray.push(VariantOptionId)
    variant1.init(this.catvalue, VariantId, VariantOptionIdArray);
    //push variants to array on ischecked=true
    if (this.isChecked) {
      if (!this.selectedVariants.some((item) => item.VariantId == variant1.VariantId)) {
        this.selectedVariants.push(variant1);
      }
      else {
        if (!this.selectedVariants.some((item) => item.VariantOptionId == VariantOptionId)) {
          let i = this.selectedVariants.findIndex((item) => item.VariantId == variant1.VariantId);
          this.selectedVariants[i].VariantOptionId.push(VariantOptionId);
        }
      }
    }
    //delete variant from array on ischecked=false
    else {
      let i = this.selectedVariants.findIndex((item) => item.VariantId == variant1.VariantId);
      let inner_i = this.selectedVariants[i].VariantOptionId.findIndex((option) => option == VariantOptionId);
      this.selectedVariants[i].VariantOptionId.splice(inner_i, 1);
      if (this.selectedVariants[i].VariantOptionId.length == 0)
        this.selectedVariants.splice(i, 1);

    }
      
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.filter.SelectedVariants = this.selectedVariants
    this.decidefunction();
  }
  getFilterData1(e: any, VariantId: number, VariantOptionId: number) {

    if (e.target.checked == true || e.target.checked == false) {
      this.isChecked = e.target.checked;
    }
    else {
      var index = this.selectedSizeArray.findIndex((x) => x == e)
      if (index > -1) {
        this.selectedSizeArray.splice(index, 1);
        this.isChecked = false;
      }
      else {
        this.selectedSizeArray.push(e);
        this.isChecked = true;
      }
    }
    let variant1 = Object.create(this.Variant);
    let VariantOptionIdArray = [];
    VariantOptionIdArray.push(VariantOptionId)
    variant1.init(this.catvalue, VariantId, VariantOptionIdArray);
    //push variants to array on ischecked=true
    if (this.isChecked) {
      if (!this.selectedVariants.some((item) => item.VariantId == variant1.VariantId)) {
        this.selectedVariants.push(variant1);
      }
      else {
        if (!this.selectedVariants.some((item) => item.VariantOptionId == VariantOptionId)) {
          let i = this.selectedVariants.findIndex((item) => item.VariantId == variant1.VariantId);
          this.selectedVariants[i].VariantOptionId.push(VariantOptionId);
        }
      }
    }

    //delete variant from array on ischecked=false
    else {
      let i = this.selectedVariants.findIndex((item) => item.VariantId == variant1.VariantId);
      let inner_i = this.selectedVariants[i].VariantOptionId.findIndex((option) => option == VariantOptionId);
      this.selectedVariants[i].VariantOptionId.splice(inner_i, 1);
      if (this.selectedVariants[i].VariantOptionId.length == 0)
        this.selectedVariants.splice(i, 1);

    }
      
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.filter.SelectedVariants = this.selectedVariants
    this.page = 1
    this.decidefunction();
  }
  getFilterPrice(minprice: any, maxprice: any) {
    if (this.selectedItem == minprice) {
      this.selectedItem = "0";
      minprice = 0;
      maxprice = 0;
    }
    else
      this.selectedItem = minprice;
    if (maxprice == "-1") {
      if (minprice.includes("Under")) {
        maxprice = minprice.split(' ')[1];
        minprice = "0";
      }
      else if (minprice.includes("Above")) {
        minprice = minprice.split(' ')[1];
        maxprice = "";
      }
      else {
        var data = minprice.split('-')
        minprice = data[0];
        maxprice = data[1];
      }
    }
    else {
      minprice = minprice == "" ? "" : "$" + minprice;
      maxprice = maxprice == "" ? "" : "$" + maxprice;
    }
    this.filter.MinPrice = minprice;
    this.filter.MaxPrice = maxprice;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;

    this.minPriceBox = minprice.split('$')[1];
    if (maxprice != "") {
      let data1 = (parseFloat(maxprice.split('$')[1])) - .01
      this.maxPriceBox = JSON.stringify(data1) == null ? "0" : JSON.stringify(data1);
    }
    else {
      this.maxPriceBox = maxprice.split('$')[1];
    }
    if (minprice != "" || maxprice != "" || this.selectedVariants.length > 0 || this.searchData != "") {
      this.page = 1
    }
    //this.getMainSearchProducts(this.catvalue, this.searchData, this.page, this.perPage)
    this.decidefunction();
  }
  getFilterReview(rate: number) {
    if (this.selectedReview == rate) {
      this.selectedReview = 0;
    }
    else {
      this.selectedReview = rate;
    }
    this.filter.AvgRate = this.selectedReview;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.page = 1
    this.decidefunction();
  }
  SortBy(sort: string) {
    this.SortData = sort;
    this.filter.SortBy = this.SortData;
    this.filter.AvgRate = this.selectedReview;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.page = 1;
    this.decidefunction();
  }
  decidefunction() {
      
    // if (this.filter.SelectedVariants.length == 0 && this.filter.MinPrice == " " && this.filter.MaxPrice == "" && this.filter.SearchData == "" && this.filter.AvgRate == 0 && this.filter.SortBy == "") {
    //   //changed
    //   this.myservice.getproductsByCategoryData(this.catvalue,this.searchData, this.page, this.perPage).subscribe(data => {
    //     this.Products = data;
    //     if (this.Products.length > 0) {
    //       this.count = this.Products[0].Count;
    //       this.pricelist = this.Products[0].PriceList;
    //     }
    //     else {
    //       this.count = 0;
    //       this.pricelist = [];
    //     }
    //   })
    // }
    // else {
    //if (this.filter)
      this.myservice.getFilterProducts(this.filter, this.page, this.perPage).subscribe((data) => {
          
        this.Products = data;
        this.Products.forEach(d => {
          let correcttime=this.datepipe.transform(d.ActiveTo, 'yyyy-MM-dd');
          d.ActiveTo=correcttime;
        });
        if (this.Products.length > 1) {
          this.count = this.Products[0].Count;
          this.pricelist = this.Products[0].PriceList;
          this.emptyProductsList=false;
        }
        else {
          this.count = 0;
          this.pricelist = this.Products[0].PriceList;
          this.emptyProductsList=true;
        }
      })

  }
  prevPage() {
    this.page = this.page - 1;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.decidefunction();
  }
  nextPage() {
    this.page = this.page + 1;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.decidefunction();
  }
  goToPage(event) {
    this.page = event;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.decidefunction();
  }
  newPageSize(e) {
    if (e == 0) {
      e = this.count;
    }
    this.perPage = e;
    this.filter.SelectedVariants = this.selectedVariants;
    this.filter.CategoryId = this.catvalue;
    this.filter.SearchData = this.searchData;
    this.decidefunction();
  }
  //render to detail page
  passTheSalt(Id: number, variantId,event) {
      
    if (event.ctrlKey) {
      window.open(this.Url, '_blank'); // in new tab
  } else
     
    this.Router.navigate(['/product-details'], { queryParams: { Id: Id, variantId: variantId } });
  }
  newTab(){
      
    window.open(this.Url, '_blank'); // in new tab
  }
  addToCart(Id: number, DetailId: number) {

    //alert(localStorage.getItem("UserId"))
    let pro = this.Products.filter(x => x.Id == Id)
    let item: CartItem = new CartItem();
    item.ProductVariantDetailId = pro[0].VariantDetailId;
    item.VendorId = pro[0].VendorId;
    item.VendorName = pro[0].VendorName;
    item.UnitPrice = pro[0].SellingPrice;
    item.Discount = pro[0].Discount;
    item.Amount = pro[0].PriceAfterDiscount;
    item.ShipmentVendor=pro[0].ShipmentVendor
    let cart: MyCart = new MyCart();
    cart.IpAddress = localStorage.getItem("IpAddress");
    cart.UserId = parseInt(localStorage.getItem("UserId") == null ? "0" : localStorage.getItem("UserId"));
    cart.TotalAmount = pro[0].PriceAfterDiscount;
    cart.CartItems.push(item);
    this.cartservice.addToCart(cart).subscribe(data => {
       this.headerData.loadView();
      if(data){
      if(cart.UserId>0)
      this.Router.navigate(['/checkout-process/checkout'])
      else
      this.Router.navigate(['/checkout-process/checkout-login'])
    }
      else
      {
        var lang = localStorage.getItem("browseLang");
        if (lang == "english") {
          this.toastr.success("Product added successfully.");
        } else {
          this.toastr.success("Producto agregado con éxito.");
        }
      this.Router.navigate(['/mycart'])
      }
      
    })
   

  }
  ActiveList() {

    this.IsGrid = true;
    this.IsList = false;
    return false;
  }
  ActiveGrid(data) {

    if (data == 1)
      this.IsGrid = true;
    else
      this.IsGrid = false;
    //return false;
  }

  ngAfterViewInit() {
    this.myservice.appDrawer = this.appDrawer;
  }
}
