export class Returnmodel {
    description:string;
  images:any[];
  product:any;
  CheckoutItemId:any;
  Quantity:number;
}
