import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { CommonService } from '../../services/common.service';
import { HttpClient } from '@angular/common/http';
import { UserLogService } from '../../services/user-log.service';

@Component({
  selector: 'app-footer-content',
  templateUrl: './footer-content.component.html',
  styleUrls: ['./footer-content.component.css']
})
export class FooterContentComponent implements OnInit {
  dataList: any;
  id:number;
  data=new CommonService();
  private url=this.data.getUri();
  content: any;
  val: any;
  Url: string;
  productId: any;
  constructor(private Router: Router,private route: ActivatedRoute,private http:HttpClient,private userLog:UserLogService) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.id = params['Id'];
      this.val=params['Name']
      if(this.id>0){
this.refreshList(this.id).then(res => this.content =res)
                    }
          })
          this.Url = this.Router.url;
      this.userLog.UserLog(this.productId, 1, this.Url, 1);
   }
refreshList(Id:number){
  return this.http.get(this.url+'FooterUrlData/getOneFooterUrlData?Id='+Id)
  .toPromise()
                    }
}
