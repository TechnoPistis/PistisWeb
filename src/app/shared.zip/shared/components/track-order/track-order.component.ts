import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { TrackService } from './track.service';
import { UserLogService } from '../../services/user-log.service';

@Component({
    selector: 'app-track-order',
    templateUrl: './track-order.component.html',
    styleUrls: ['./track-order.component.css']
})
export class TrackOrderComponent implements OnInit {
    Url: string;

    constructor(
        public toastr: ToastrService,
        public Router: Router,
        private route: ActivatedRoute,
        public _service: TrackService,private userLog:UserLogService
    ) { }

    OrderId: any;
    TopData: any;
    OrderDeattails: any[] = [];
    checkoutItems: any[] = [];
    Preparing: any;
    Packed: any;
    Shipped: any;
    Delivered: any;
    TotalAmount: any;
    userId: any;

    ngOnInit() {
          
        this.userId = window.localStorage.getItem('UserId');
        // if (!(+this.userId > 0))
        //     this.Router.navigate(['/']);

        this.route.queryParams.subscribe(params => {
            this.OrderId = params['orderId'];
        });
        // this.OrderId = window.localStorage.getItem("OrderId");
        if (this.OrderId) {
            this.trackOrder();
        }
        else {
            var lang = localStorage.getItem('browseLang')
            if (lang == 'english') {
                this.errMsg = "Order not found. . .";
            } else {
                this.errMsg = "Orden no encontrada. . .";
            }

        }
        this.Url = this.Router.url;
      this.userLog.UserLog(0, 1, this.Url, 1);
    }
    getproductId(id: number, PvdId: number) {
        console.log(id)
        this.Router.navigate(['/RatingReview'], { queryParams: { Id: id, ProductVdId: PvdId } });
    }


    goToDetail(Id, variantId) {
        if (+Id && +variantId) {
            this.Router.navigate(['/product-details'], { queryParams: { Id: Id, variantId: variantId } });
        }
    }

    errMsg: any;
    trackOrder() {
        if (+this.OrderId) {
            this._service.track(+this.OrderId).subscribe((data: any) => {
                
                console.log(data)
                if (data == "404") {
                    var lang = localStorage.getItem('browseLang')
                    if (lang == 'english') {
                        this.errMsg = "Order not found. . .";
                    } else {
                        this.errMsg = "Orden no encontrada. . .";
                    }

                }

                var name = "";
if(data.OrderDetail.User!=null)
{
                if (data.OrderDetail.User.MiddleName && data.OrderDetail.User.LastName)
                    name = data.OrderDetail.User.FirstName + " " + data.OrderDetail.User.MiddleName + " " + data.OrderDetail.User.LastName;
                if ((!data.OrderDetail.User.MiddleName) && data.OrderDetail.User.LastName)
                    name = data.OrderDetail.User.FirstName + " " + data.OrderDetail.User.LastName;
                if ((!data.OrderDetail.User.MiddleName) && (!data.OrderDetail.User.LastName))
                    name = data.OrderDetail.User.FirstName;
                if ((data.OrderDetail.User.MiddleName) && (!data.OrderDetail.User.LastName))
                    name = data.OrderDetail.User.FirstName + " " + data.OrderDetail.User.MiddleName;
}

                var address = "";
                if (data.DeliveryAddress.Colony && data.DeliveryAddress.Street && data.DeliveryAddress.City && data.DeliveryAddress.StateName
                    && data.DeliveryAddress.Pincode) {
                    address = data.DeliveryAddress.Colony + "," + data.DeliveryAddress.Street + "," + data.DeliveryAddress.City + "," +
                        data.DeliveryAddress.StateName + " - " + data.DeliveryAddress.Pincode;
                }
                if (data.DeliveryAddress.Colony && (!data.DeliveryAddress.Street) && data.DeliveryAddress.City && data.DeliveryAddress.StateName
                    && data.DeliveryAddress.Pincode) {
                    address = data.DeliveryAddress.Colony + "," + data.DeliveryAddress.City + "," +
                        data.DeliveryAddress.StateName + " - " + data.DeliveryAddress.Pincode;
                }

                if (data.DeliveryAddress.Colony && (data.DeliveryAddress.Street) && data.DeliveryAddress.City && data.DeliveryAddress.StateName
                    && data.DeliveryAddress.Pincode) {
                    address = data.DeliveryAddress.Colony + "," + data.DeliveryAddress.City + "," +
                        data.DeliveryAddress.StateName + " - " + data.DeliveryAddress.Pincode;
                }

                var model = {
                    Name: name,
                    Address: address,
                    Phone: data.DeliveryAddress.PhoneNo,
                    Coins: data.OrderDetail.DiscountForLoyalityPoints,
                    TotalAmount: data.OrderDetail.TotalAmount,
                    DeliveryDate: data.OrderDetail.DeliveryDate
                };
                this.TopData = model;

                this.OrderDeattails = [];

                if (data.checkoutItems.length > 0) {
                    this.checkoutItems = data.checkoutItems;
                    this.errMsg = null;
                }

                switch (data.Status) {
                    case "Preparing": {
                        this.Preparing = "progtrckr-done";
                        this.Packed = "progtrckr-todo";
                        this.Shipped = "progtrckr-todo";
                        this.Delivered = "progtrckr-todo";
                        break;
                    }
                    case "Packed": {
                        this.Preparing = "progtrckr-done";
                        this.Packed = "progtrckr-done";
                        this.Shipped = "progtrckr-todo";
                        this.Delivered = "progtrckr-todo";
                        break;
                    }
                    case "Shipped": {
                        this.Preparing = "progtrckr-done";
                        this.Packed = "progtrckr-done";
                        this.Shipped = "progtrckr-done";
                        this.Delivered = "progtrckr-todo";
                        break;
                    }
                    case "Delivered": {
                        this.Preparing = "progtrckr-done";
                        this.Packed = "progtrckr-done";
                        this.Shipped = "progtrckr-done";
                        this.Delivered = "progtrckr-done";
                        break;
                    }
                    default: {
                        this.Preparing = "progtrckr-todo";
                        this.Packed = "progtrckr-todo";
                        this.Shipped = "progtrckr-todo";
                        this.Delivered = "progtrckr-todo";
                        break;
                    }
                }
            })
        }
    }
}