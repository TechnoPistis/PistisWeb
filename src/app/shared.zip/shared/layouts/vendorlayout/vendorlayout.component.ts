import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-vendorlayout',
  templateUrl: './vendorlayout.component.html',
  styleUrls: ['./vendorlayout.component.css']
})
export class VendorlayoutComponent implements OnInit {
  constructor(public translate: TranslateService,
    public _route: Router) {
    translate.addLangs(['english', 'español']);
    translate.setDefaultLang('english');
    const browseLang = translate.getBrowserLang();
    translate.use(browseLang.match(/english|español/) ? browseLang : 'english');
  }

  ngOnInit() {
    if (window.localStorage.getItem("RoleId") != "2")
this._route.navigate(["/"]);
  }
  ngAfterViewInit() {
    $('[name="front-style"]').attr('disabled', 'disabled');
    $('[name="admin-style"]').removeAttr('disabled');
  }

  logout() {
    localStorage.removeItem('UserName')
    localStorage.removeItem('UserId')
    localStorage.removeItem('RoleId')
    this._route.navigate(["/"]);
  }

}
