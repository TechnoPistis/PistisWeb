export class BannerUpload {
    Id:number=0;
      ImageUrl:any=[];
      view:any=[];
      side:any=[]
      Position:any=[]
     ImageUrl1:any=""
     ImageUrl2:any=""
     ImageUrl3:any=""
     ImageUrl4:any=""
}
