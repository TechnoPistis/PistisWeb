export class Category {
    Id:number;
    Name:string;
    ParentId:number|null;
    Icon:string;
    IsActive:boolean;

 }
 