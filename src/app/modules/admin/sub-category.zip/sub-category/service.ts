export class Service {
   Id:number;
   Name:string;
   subId:number
 SpanishName:string
 IsAdult:boolean=false
 
 
}
