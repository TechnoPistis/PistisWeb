export class Vendor {
      Id: number;
      Address:string;
      Email:string;
      Company: string;
    //  CompanyId:number;
      Phone:string;
      StateId:number;
      State:string;
      CountryId:number;
      DOB:any;
      City:string;
      LanguageId:number;
      GenderId:number;
      TwitterId:string;
      FacebookId:string;
      PostalCode:string;
      FirstName:string;
      MiddleName:string;
      LastName:string;
      DisplayName:string;
      UserName:string;
      Password:string;    
      Image: string;
      Logo:string;
      IdProof: string;
      ConfirmPassword: string;
      RFC:string;
}
