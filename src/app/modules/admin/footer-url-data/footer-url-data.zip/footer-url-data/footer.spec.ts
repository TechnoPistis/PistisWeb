import { Footer } from './footer';

describe('Footer', () => {
  it('should create an instance', () => {
    expect(new Footer()).toBeTruthy();
  });
});
