export class Footer {
    Id:number
    Data:string
    FooterUrlId:number
    IsActive:boolean
    FooterUrl:[]
}
