export class BannerImage {
    Id:number;
    Image:string;
    Url:string;
}