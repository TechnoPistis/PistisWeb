import { Component, OnInit } from '@angular/core';
import { VariantService } from '../variants.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../../products/product.service';

@Component({
  selector: 'app-variants',
  templateUrl: './variants.component.html',
  styleUrls: ['./variants.component.css']
})
export class VariantsComponent implements OnInit {


  variantList: any[] = [];

  constructor(
    private _service: VariantService,
    private _router: Router,
    private toastr: ToastrService,
    private _productService: ProductService
  ) { }

  ngOnInit() {
    debugger
    this.getAllVariants();
    this.getCategories();
  }

  filterVariants(value) {
    debugger
    if (value) {
      this._service.getVariantsByCategory(value).subscribe((data: any) => {
        this.variantList = [];
        this.variantList = data;
      })
    }
    else
      this.getAllVariants();
  }

  Categories: any[] = [];

  getCategories() {
    this._productService.getSubcategories().subscribe((data: any) => {
      debugger
      this.Categories = [];
      this.Categories = data;
    })
  }

  getAllVariants() {
    this._service.getAllVariants().subscribe((data: any) => {
      this.variantList = [];
      this.variantList = data;
    });
  }

  editVariant(id: any) {
    if (id) {
      this._router.navigate(['/admin/variants/edit'], { queryParams: { Id: id } });
    }
  }

  deleteVariant(id: any) {
    if (id) {
      if (confirm('Are you sure want to delete !')) {
        this._service.deleteVariant(id).subscribe((data: any) => {
          debugger
          this.toastr.success('Deleted successfully !');
          this.getAllVariants();
        })
      }
    }
  }
}
