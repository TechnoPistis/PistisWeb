export class Category {
    Id:number;
    Name:string;
    SpanishName:string;
    ActualIcon:string;
    Icon:string
    constructor(){
        this.Id=null;
        this.Name=null;
this.SpanishName=null;
this.ActualIcon=null;
this.Icon=null
    }
}
