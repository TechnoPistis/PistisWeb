import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../product.service';
import { ToastrService } from 'ngx-toastr';
import { GlobalErrorHandlerService } from 'src/app/shared/services/global-error-handler-service.service';
// import { Product } from '../../../../shared/models/product.model';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { Product } from '../../product.model';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  public Products: any = [];
  Categories: [];
  SelectedCategory: 0;

  count: number = 0; page: number = 1; perPage: number = 8; pagesToShow: number = 10;
  SearchName: any;

  constructor(public service: ProductService, private toaster: ToastrService
    , private error: GlobalErrorHandlerService, public translate: TranslateService, public Router: Router) {

  }

  pageSize: any;

  ngOnInit() {
    this.page = 1;
    this.pageSize = 10;
    this.SearchName="";
    this.getCategories();
    this.getProducts();
  }

  getProducts() {
    this.service.getProduct(this.page, this.pageSize,this.SearchName).subscribe((data: any) => {
      if (data.data) {
        this.Products = data.data;
        this.count = data.count;
      }
    })
  }
 //onEnable
 onEnable(id: number,val:number) {
  if(val==1){

  
 if (confirm('Are you want to enable this product?')) {

   this.service.enableProduct(id).subscribe(res => {
    this.getProducts();
     this.toaster.warning('Enabled successfully', 'product !');
   });
 }
}else{
 if (confirm('Are you want to disable this product?')) {

   this.service.disableProduct(id).subscribe(res => {
     debugger
     this.toaster.warning('Disabled successfully', 'product !');

     this.getProducts();
   
   });
 }
}
}
  getCategories() {
    this.service.getSubcategories().subscribe(data => {
      var result = [];
      result.push(data);
      this.Categories = result[0];
    })
  }
  addProduct() {
    this.Router.navigate(['/admin/products/product']);
  }
  editProduct(id: number) {
    
    this.Router.navigate(['/admin/products/edit'], { queryParams: { Id: id } });
  }

  ViewProduct(id: number) {
    this.Router.navigate(['/admin/products/edit'], { queryParams: { Id: id, viewOnly: true } });
  }

  deleteProduct(id: number) {
    if (confirm('Are you sure to delete this product?')) {
      this.service.deleteProduct(id).subscribe(res => {
        this.service.getProduct(this.page, this.pageSize,this.SearchName).subscribe(data => {
          this.Products = data;
        })
        this.toaster.warning('Deleted successfully', 'Category !');
      });
    }
  }
  openFilter() {
    this.SelectedCategory = 0;
  }
  filter(ProductCategoryId: number, Availability: string) {
    this.service.getFilterProducts(ProductCategoryId, Availability).subscribe(data => {
      this.Products = data;
    })
  }
  SearchByName(SearchName: string) {
    this.service.getProductsByName(SearchName).subscribe(data => {
      this.Products = data;
    })
  }


  prevPage() {
    this.page = this.page - 1;
    this.getProducts();
  }
  nextPage() {
    this.page = this.page + 1;
    this.getProducts();
  }
  goToPage(event) {
    this.page = event;
    this.getProducts();
  }

  newPageSize(e) {
    if (e == 0) {
      e = this.count;
    }
    this.perPage = e;
    this.getProducts();
  }

  searchProduct(){
    this.getProducts();
  }

}
